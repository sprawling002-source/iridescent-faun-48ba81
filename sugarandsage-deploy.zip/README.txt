Sugar & Sage - Fixed Deploy Folder
==================================
This folder fixes the Edge vs Chrome image bug.

Contains:
- index.html (store, fixed)
- admin.html (admin, fixed)
- _redirects (Netlify routing fix)
- netlify.toml (headers)

HOW TO DEPLOY:
Option A - Drag & Drop (easiest):
1. Go to app.netlify.com > Your site > Deploys
2. Drag this ENTIRE folder onto the deploy area
3. Done - sugarandsage.co.za will update

Option B - GitHub:
1. Replace your repo's index.html with this index.html
2. Replace admin.html with this admin.html
3. Add _redirects and netlify.toml to repo root
4. git add . && git commit -m "fix edge images" && git push

After deploy, clear Edge cache: Ctrl+Shift+Delete > Cached images > Clear, then Ctrl+F5

Admin: open /admin.html, edit products, Export for Live Site, paste array into index.html
